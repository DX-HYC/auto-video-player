# 更新日志

### v2.2.4（2026-11-20）优化网梯平台「偶尔无法自动连播」

**用户反馈**：网梯科技平台偶尔出现播完不跳、跳了不播、或反复停在同一节课。

**六个偶发根因**

1. 子帧 `reportVideoState()` 用 `postMessage` 上报 `localList`，其中 `container` / `leaves[].el`
   是 DOM 元素，结构化克隆直接抛 `DataCloneError`，被 `postToTop` 的 try/catch 静默吞掉。
   只要某个子帧识别出目录片段，该帧整条状态上报就消失，顶层看不到 iframe 里的视频，
   「卡结尾补跳」时灵时不灵 —— 这是「偶尔」的主因。
2. `clickNext()` 的 2 秒跳转校验只写日志（「⚠️ 当前项未变化」）不做补救，而
   `lastClickAt`(4s) / `lastGlobalNextAt`(8s) 两个锁已经占用；视频播完不会再有 ended 事件，
   于是这一节停住，只能等每分钟一次的后台闹钟。
3. `dispatchNext()` 把跳转委派给子帧后没有回执：iframe 切课时被重建，消息无人接收，
   8 秒锁内不重试，本次跳转直接丢失。
4. 前台 3 秒主心跳里没有「停结尾」检测，只有后台 alarm（1 分钟）触发 `watchdogTick()`；
   ended 事件在播放器重建时丢失就要等很久。
5. `handlingEnd` 是布尔锁，靠 `setTimeout(2000)` 复位；后台标签页里 setTimeout 被节流到
   分钟级，会把新一节课的 ended 事件整段吞掉。
6. `localDoneMap` 只用 DOM 元素做 key，Vue 重渲染目录后引用失效、完成记账丢失，
   `findNextItem()` 又会选中当前这一节，表现为「反复跳同一集 / 不前进」。

**修复：新增网梯连播自愈层（只做确认与补偿，不改任何判定语义）**

- `plainList()`：仅网梯 profile 下把 `localList` 转成纯数据副本上报，并预计算
  `catalogReal`；`hasRealCatalogInList()` 优先采信该结论。跨帧视频状态稳定可见。
- `armJumpVerify()` / `verifyJump()` / `retryJump()` / `finishJump()`：跳转后 2.2 秒确认
  当前课时是否真的切换；未生效最多补偿 3 次，每次清掉跳转锁、重新分析目录。
  **前两次重点同一目标**（平台状态可能只是刷新慢，不会跳课），第三次才顺序换目标；
  目录高亮没刷新但新课时已起播也判成功，避免重复点击。用尽后停手并放开锁，等下一轮巡检；
  确认成功后给 12 秒补跳冷却，防止旧视频的「已结束」状态在 frameStates 里残留造成重复跳课。
- `itemKey()` + `localDoneKeys`：基于网梯 itemId（其次课时文本）的稳定完成记账，
  SPA 重渲染后仍有效；`nextHealTarget()` 跳过上次点过没生效的目标、跳过已完成课时，
  按目录顺序推进，不再原地打转。
- 子帧跳转点击发 `nextAck` 回执，顶层统一确认（子帧各自补偿会重复点击）；
  `delegatedNextAt` 超过 3.5 秒无回执时顶层接管重试。
- `whatyHealTick()` 接入顶层 3 秒心跳：`whatyStuckEnded()` 识别「paused 停在结尾」
  （原 `hasStuckEndedVideo()` 要求 `!paused`，网梯播完自动暂停会漏判），12 秒节流后
  主动 `dispatchNext()`；不再只依赖每分钟一次的后台闹钟。
- 确认切课后立即 + 1.5s + 3.5s 三次 `broadcastDown({type:'ping', play:true})`，
  各级 iframe 收到后立刻 `ensurePlaying()`，覆盖 iframe 重建时序，修「跳了不播」。
- `handlingEnd` → `handlingEndAt` 时间戳判定，后台节流下按真实时间自然过期。
- SPA 路由变化时重置 `pendingNext` / `lastAutoTarget` / 委派与回执时刻，避免旧一轮干扰。

**隔离与边界**

- 全部新增逻辑由 `whatyHealOn()` 把关：必须 `ACTIVE_PROFILE === 'whaty'`、平台未被前台停用、
  已完整启动且开启自动连播。`jxnu` / `generic` 完全不走这一层；跨帧纯数据上报同样只在网梯生效。
- **未改动冻结语义**：`findWangtiCatalog()` / `hasCompletedMarker()` / `hasCurrentMarker()`
  与 `PLATFORMS.frozen` 原样保留，`tests/selftest_whaty_frozen.js` 继续作为回归门禁。
- 补偿有上限（3 次）且有节流，不会连点乱跳；用户手动暂停、手动下一集不触发自愈。
- 授权 / 心跳 / UI / 在线离线双通道行为不变。

**测试**

- 新增 `tests/selftest_whaty_heal.js`（68 项）：21 条源码隔离断言 + 47 条行为仿真
  （平台隔离、纯数据克隆、停结尾判定、目标去重、补偿次数上限、成功起播唤醒、前台巡检兜底、
  成功后的 12 秒冷却防重复跳课）。
- `tests/selftest_robust.js` 的 C9 断言同步为「ping 带 play 标记透传」。
- 全量回归 `node tests/run-all.js` **392/392 通过**。

### v2.2.3（2026-11-14）修复「已授权用户断网太久又要重新授权」

**用户反馈**：已授权用户断网时间稍长就弹出「插件未授权 · 与授权服务器断开过久，请检查网络或重新激活」。用户不可能 7×24 在线，断网后重新联网且仍在正常授权期限内的，不应重复授权。

**两个根因**

1. `computeStatus()` 把在线会话限定为「17 秒内成功心跳 + 5 分钟宽限」，超过 5 分钟就返回 `ok:false / reason:session-lost`。断网几小时必然停手。
2. 更隐蔽：服务端 JWT 有效期 24h、refresh 窗口更短。连续断网数天后重连，心跳 401 → `refresh()` 也 401 → `lastOkAt` 永不更新 → **永久卡在重新激活**，即使卡密本身没到期。旧逻辑没有任何自动恢复路径。

**修复**

- `auth-online.js`
  - 新增 `localLicenseValidity(s, now)`：`s.revoked` 或本地期限已过才判失效。服务端返回过 `expireAt` 时，到期后再给 **7 天联网核验窗口**；没返回期限时从最后一次成功校验起算 **90 天兜底**；没有时间信息则不误杀。
  - `computeStatus()` 重写：心跳新鲜 → `online`；否则只要本地凭证在期限内 → `ok:true`，`mode=grace`（5 分钟内短暂抖动）或 `disconnected`（长期离线），`source` 恒为 `online`。文案明确「联网后自动恢复，无需重新激活」，旧的 `session-lost` 分支与「断开过久」提示彻底移除。
  - 新增 `reverify()`：`heartbeat()` 拿到 401 且 `refresh()` 也返回 401/403/410 时，用激活时保存在本地的 `authCode` 静默重新激活（5 分钟节流），成功后用新令牌补一次心跳。只有服务端明确判「已到期 410」才写 `revoked`；卡密被后台改名/迁移（404）、设备待审核 423、限流 429 之类补救失败一律保持离线可用并稍后重试 —— 停用/到期由心跳的 403/410 权威同步，不能因一次补救请求失败就误杀已付费用户。纯网络故障（code -1）不触发重激活，也不撤销授权。
  - 心跳成功后清 `reverifyAt`；`CONFIG` 新增 `EXPIRE_VERIFY_GRACE_MS` / `UNKNOWN_EXPIRE_MS` / `REVERIFY_MIN_MS`，`GRACE_MS` 降级为纯提示阈值。
- `background.js`：`onHeartbeatTick()` 改为**只要还有 token 就维持 offscreen 心跳通道**（30 秒节流补建），不再依赖 `state.source === 'online'`；后台已停用时降频到每分钟重试一次，续费/解封后仍会自动恢复。断网期间通道若被回收，重连后再也没人同步服务端状态，这是「卡死」的另一半原因。
- `content.js`：`localFallbackState()`（SW 不可达时）改用同一套授权期限规则，删掉 `AUTH_GRACE_MS`；未授权卡片补充「在线卡密断网不失效、联网自动恢复、无需重新激活」。
- `popup.js`：`renderLicense()` 支持 `disconnected` 模式（📴 离线可用 · 联网后自动恢复），未授权说明同步。

**兼容性**：离线码（`AVP1`）仍是完全独立的凭证，行为不变；服务端 403/410 强制下线、到期停手依然生效，只是改为「联网后同步」。老用户升级到 v2.2.3 无需重新激活 —— 本地 `authCode` 从 v2.2.0 起就已持久化。

**验证**：`node tests/run-all.js` **322/322 通过**（新增 34 项：断网 3/30/60 天仍可用、到期 7 天核验窗口、未知期限兜底、令牌过期自动重激活、节流、服务端明确到期、纯网络故障、前后台源码级门禁）。

### v2.2.2（2026-11-13）授权站启用 SSL，在线通道全面切到 https

**服务端已配置有效证书**（实测 `ssl_verify=0`）：`docs/api.php`、`admin/login.php`
返回 200，`init.php` 的 HTTPS POST 正常返回 RSA 公钥，http 已 301 跳转到 https。

- `auth-online.js`：`API_BASE` 由 `http://` 改为 `https://auth.dixunblog.cn/api/v2/`；
  注释里的接口地址同步。激活、心跳、刷新、试用等子请求都基于该常量，一处改动全覆盖。
- `manifest.json`：版本 2.2.2。`host_permissions` 原本就是 `*://auth.dixunblog.cn/*`，
  同时覆盖 http/https；CSP 未限制 `connect-src`，**权限与 CSP 均无需改动**。
- `tools/check-online.js`：网络失败排查建议改为证书 / 301 / https 地址检查。
- `tests/selftest_online.js`：新增源码级门禁断言「API_BASE 必须以 https:// 开头」，
  防止以后误退回明文；`tests/selftest_license.js` 版本断言同步 2.2.2。
- `README.md`：更新安全须知。老包（v2.2.1）的 http 请求会被 301 自动跟随，
  **不升级也不会立刻失效**，持 `AVP1` 离线码的用户完全不受影响。
- 服务端加固包 `server-hardening/`：curl 验证命令全部改为 https，SSL 状态改为已完成，
  补充 HSTS 建议；`docs-access-control.zip` 同步重打。

**验证**：`node tools/check-online.js` 走真实 https 取公钥成功；`node tests/run-all.js`
全绿；证书链、301 跳转、接口返回均实测通过。

### v2.2.1（2026-11-12）填入真实 AppKey + 真实服务器验证 + 双授权兼容加固

**真实服务器端到端验证通过**：填入后台 AppKey 后用真实卡密跑通
`init.php → activate.php → heartbeat.php`，返回「激活成功 · 剩余 30 天」、心跳 200，
签名模式 `values`（与文档「安全机制」章节一致，无需启用 Python 示例的 `key=value` 写法）。
v2.2.0 包里是占位 AppKey，本版为**首个可直接分发的在线授权版本**。

**双授权兼容（用户要求：原来的授权不受影响）**
- `auth-online.js` 的 `computeStatus()` 改为：在线会话有效时优先按在线显示；其余情况
  只要本机有作者签发的有效 `AVP1` 离线码就**独立放行**，不受在线会话过期、断网宽限、
  后台 403/410 停用或到期影响。v2.1.x 老用户升级后**无需重签、无需重新激活、无需联网**。
  强制下线仅对「没有离线码」的纯在线用户生效 —— 离线码是作者亲手签发的独立凭证。
- `background.js`：离线码激活不再创建离屏文档；`onHeartbeatTick()` 在无线上令牌时
  提前收手并关闭离屏文档，纯离线码用户不会被 5 秒节拍无谓唤醒，也不发任何网络请求。
- `popup.js`：后台 SW 暂不可达时，输入 `AVP1` 码仍可本地验签激活（与网页卡片一致）。
- `content.js`：SW 无响应的降级等待由 15 秒压到 6 秒；未授权卡片、弹窗文案改为明确
  列出两种授权，说明旧码无需联网、升级后自动继续有效。

**测试**：新增 17 项兼容断言（老用户升级零请求、离线码跨 revoked/session-lost、
在线优先、popup 本地兜底、真实 AppKey 已写入等），全量回归 **287/287 通过**。

### v2.2.0（2026-11-12）接入 V2 在线授权系统（在线卡密 + 应急离线码）

主授权通道改为作者自建的 `auth.dixunblog.cn/api/v2/` 在线授权系统：`init / activate /
heartbeat / refresh` 五个接口，RSA-2048 加密传输、SHA-256 签名、JWT 令牌、5 秒心跳、
后台可远程停用。授权仍为**程序级**（不绑定域名/平台），激活后全功能全站可用。
原离线授权码保留为**应急备用通道**（服务器宕机/断网时本地验签生效）。

**接入要点**
- 新增 `auth-online.js`：纯 JS BigInt 实现 RSAES-PKCS1-v1_5 分块加密（WebCrypto 不
  支持 v1.5 加密，只支持 OAEP）；浏览器无硬件序列号，用扩展持久设备 ID + 运行环境
  构造满足文档格式（≥3 个 64 位 hex 组件）的指纹；封装 5 个接口与状态机。
- 开发文档「安全机制」（只拼参数值）与 Python SDK 示例（`key=value&…`）签名写法矛盾：
  默认按前者，激活失败自动换后者重试并记住可用模式；`check-online.js --sign-mode kv`
  可强制指定。
- 新增 `offscreen.html/js` + `heartbeat-worker.js`：MV3 Service Worker 会被回收、
  `chrome.alarms` 最小 30 秒，用离屏文档里的 Web Worker 承载 5 秒节拍，经
  `runtime.Port` 点对点唤醒 SW 执行心跳（不广播给所有标签页），每分钟闹钟兜底重建。
- `background.js` 新增授权消息总线（`apAuthState / apAuthActivate / apAuthClear /
  apAuthRefresh / apAuthTrial`），所有网络请求由 SW 发起 —— content script 在 https
  学习页里 fetch http 会被混合内容策略拦截。状态单点存 `storage.local`，变化时广播
  `apAuthChanged`，相同状态不发消息（避免 5 秒一次的消息风暴）。
- `content.js` / `popup.js` 授权闸门改为向后台查询 + 订阅广播；SW 不可达时读本地缓存
  降级（最近心跳在宽限内继续可用），应急离线码可本地验签兜底。
- 断网宽限 5 分钟；后台「到期 410 / 强制下线 403」立即停手且**不回落应急码**；
  JWT 临近过期自动 `refresh.php`；心跳 401 自动刷新后重试。

**顺带修复的安全漏洞**
- `boot()` / `startFull()` 原先没有授权守卫：待命观察器在授权被清除后仍可能唤醒完整
  启动，绕过授权闸门。现在两处都加了状态检查。

**作者工具（不随买家分发）**
- `tools/set-appkey.js`：写入授权系统 AppKey / API 地址（**分发前必跑**）。
- `tools/check-online.js`：真实服务器连通性与端到端自检（init → activate → heartbeat）。
- `tools/gen-license.js`：保留，用于签发应急离线码。

**manifest**：版本 2.2.0；新增 `offscreen` 权限与 `auth.dixunblog.cn` host 权限。
**测试**：新增 `tests/selftest_online.js`（81 项，含 Node RSA 私钥解密验证密文、签名
自适应、错误码、宽限状态机），全量门禁 **269/269 通过**。

**待办**：作者需填入真实 AppKey 并用一张真实卡密跑 `check-online.js --code` 做真实
服务器端到端验证；建议给开发文档加访问控制、给服务器配置 SSL（当前仅 http，
`CLIENT_SECRET` 明文暴露在文档页）。

### v2.1.2（2026-10-27）全栈体检：5 个 bug 修复 + 性能优化

对全部源码（manifest / background / content / popup / license / shadow_bridge，约 4900 行）
做了一次完整通读，修复确认的问题：

**Bug 修复**
- `readCustomPlayer()` 调用了未定义的 `pick()`：「时长读不到」的分支一进去就抛
  ReferenceError，被外层 try 静默吞掉 —— playing 判定与进度条兜底整段丢失，
  自定义播放器会被永远当成"暂停中"（现有测试都走"时长读得到"的分支，从未覆盖）。
- SPA 路由监听的重复注册：页面先待命再被播放内容唤醒时会再次调用 `watchSpaRoute()`，
  导致 popstate/hashchange 监听器叠加、`history.pushState` 被反复包装、1500ms 轮询
  interval 越积越多（且不在 tickTimers 里，待命时清不掉）。改为监听器只装一次 +
  轮询纳入 tickTimers 统一管理。
- background 标签页注册竞态：`addTab/removeTab` 原是"异步读 storage → 改 → 写回"，
  两个标签页几乎同时注册时后写覆盖先写（丢更新），被丢的标签页再也收不到看门狗
  唤醒。改为内存数组为单一事实源 + 启动时恢复一次（单 Promise 去重）。
- Shadow 桥升级后不刷新 matches：扩展升级后若域名清单变了，已注册的 MAIN world
  桥不会更新，新域名上永远注入不了。改为注册前逐项比对，过期则 updateContentScripts
  （老内核自动降级为"注销 → 重注册"）。
- 面板"空壳 video"统计错误：用"全部 - 按 src 去重后的真实视频数"相减，页面存在
  重复 src 的 video 时会虚报空壳数量。改为直接按 isRealVideoObj 统计。

**健壮性**
- `chrome.tabs.sendMessage` 同时兼容 callback 与 Promise 两种 API 形态（此前直接
  `.catch()`，在只支持 callback 的内核上会抛 TypeError 导致后续标签页全部漏 ping）。
- 起播复查定时器（3s/8s/16s 三连）重新调度前先作废旧句柄，防止播放卡住时定时器堆积。
- 待命唤醒后断开待命观察器，避免与主观察器重复触发同一批扫描。
- Shadow 播放器的起播条件对齐 autoStart 开关（此前绕过开关只看 currentTime<15）。
- ping 消息向孙辈 iframe 转发（嵌套 iframe 此前收不到顶层心跳）。
- 面板/popup 的倍速下拉在存储值不在选项内时动态补选项，不再显示空白；
  updateUI 对面板控件逐个空值保护。

**性能**
- video 元素清单缓存：`queryVideos()` 原先用 `querySelectorAll('*')` 遍历全文档每一个
  元素找 shadow 宿主，被状态上报（1.5s）/保播（3s）/倍速等多条路径高频重复调用。
  现在绑定路径永远全量刷新，读取路径走 1.5s TTL 缓存（新增元素由 MutationObserver
  即时刷新），大页面 CPU 占用显著下降。
- 目录容器查找缓存：`findCatalogContainer()` 每 1.5~3 秒跑三十多组全文档扫描 +
  getBoundingClientRect 评分，加 1.2s TTL 缓存（document.contains 校验，SPA 换课时
  旧容器 detached 立即重扫）。

**测试**
- 新增 `tests/selftest_robust.js`（44 项）：readCustomPlayer 真实行为测试（DOM 桩，
  锁死 pick bug）、background 行为测试（chrome API 桩：竞态/桥刷新/消息双形态）、
  17 项修复源码断言。全量回归 184/184 通过。

### v2.1.1（2026-10-27）授权改为程序级：不绑定域名/平台

起因：授权不应针对某个域名或平台——用户购买的是"这个程序的使用授权"，授权后应能使用全部功能。

- `license.js`：授权码 payload 去掉域名字段，只保留版本 + 过期时间 + 客户号 + 备注；
  校验不再进行域名匹配，**同一授权码在任何网站、任何平台都有效**；
  旧版（v2.1.1 前）签发的带域名授权码签名仍然有效且同样不再受域名限制，无需重签。
- 未授权提示卡：移除「当前网站域名 + 一键复制」行（程序级授权不再需要域名信息），
  保留失败原因、作者联系方式、授权码输入框。
- popup 授权卡：授权信息由「适用网站 xxx」改为「程序级授权（全部功能 · 全部已支持网站）」；
  未授权引导语由"把网站域名发给作者"改为"联系作者购买授权"。
- `tools/gen-license.js`：`--domain` 不再是必填（传入会被忽略并提示），
  签发命令简化为 `node tools/gen-license.js --days 365 --customer CUST-001`，
  转发话术同步改为"授权不绑定网站，激活后全部功能可用"。
- 测试：`tests/selftest_license.js` 升级为 51 项，新增「任意域名均放行」「payload 不含
  域名字段」「旧带域名码全站有效」「提示卡无域名行」等断言；全量回归 140/140 通过。

### v2.1.0（2026-10-27）商业授权 + 修复"任何网页都蹦出插件"

**一、商业授权（未授权不工作）**

起因：准备商业化售卖，要求没有授权就无法使用插件，并提示用户联系作者授权。

- 新增 `license.js`：离线授权码方案，**不需要服务器**。
  - 授权码 = `AVP1` + base32(payload) + HMAC-SHA256 签名，payload 含绑定域名（可多个，含子域）、
    过期时间（0=永久）、客户号、备注；
  - SHA-256/HMAC 为同步实现，**不依赖 crypto.subtle**（http 网站没有该 API），
    content script / popup / Node 生成器三方共用同一份代码，算法永不漂移；
  - base32 用 Crockford 字符集（无 I/L/O/U），授权码可按 5 字符分组显示，用户粘贴时空格/
    连字符/小写全部容错。
- 未授权时的行为（硬性策略）：`checkLicense()` 不通过 → **不扫描、不起播、不建面板、
  不注册看门狗**，只在页面右下角显示「🔒 插件未授权」卡片：失败原因、作者联系方式、
  授权码输入框（回车/点激活即生效）、当前网站域名一键复制（发给作者签发用）。
- 激活即生效：写入 `chrome.storage.sync.licenseKey`，已打开页面通过 storage.onChanged
  收到变化立即启动，无需刷新；授权被清除/失效时 `recheckLicense()` 立即 `enterStandby()` 停手。
- popup 顶部新增授权卡：状态（✅ 已授权/客户号/到期/适用网站 或 🔒 原因+联系方式）、
  激活输入框、清除授权。popup 里 hostname 传空、跳过域名匹配（拿不到标签页域名），
  域名终检由网页里的 content script 用真实 hostname 完成。
- 新增 `tools/gen-license.js`（作者工具，**不随买家分发包**）：
  `node tools/gen-license.js --domain zjpt-web.jxnu.edu.cn --days 365 --customer CUST-001`，
  输出分组授权码 + 授权摘要 + 可直接转发的话术；生成后自动自检。支持 `--forever`、多域名、
  自定义备注、`--secret` 轮换兼容。
- 安全边界（如实）：密钥内置在 license.js，可挡普通用户、挡不住专业逆向；需要更强保护
  应改服务器在线校验。轮换密钥 = 改 `SIGN_SECRET` 重新打包，旧码全部作废。
- 新增 `tests/selftest_license.js`（48 项）：SHA-256 标准向量（FIPS 180-4）、base32 往返、
  有效码/子域/容错/域名不匹配/篡改/错误密钥伪造/过期/永久/多域名/格式错误/popup 预检/
  版本过旧/提示文案必含作者联系方式，以及 content.js 授权闸门与待命守卫的源码级断言。

**二、修复"安装后任何网页都蹦出插件并运行"**

排查结论：manifest 的 `content_scripts` 本来就是 27 域名白名单，问题在运行逻辑——
`shouldEarlyExit()` 判定为"域名在白名单就不早退"，于是白名单站点里的普通页面
（首页、空间页等没有任何视频的页面）也会建面板 + 3s 心跳；`all_frames:true` 还让
任何嵌了白名单 iframe 的网页都在子帧里跑扫描。三层修复：

1. **启动状态机**（content.js）：`boot()` 先探测播放内容特征（video / audio[src] /
   画布播放器 / 目录容器 / 白名单 iframe / player·video 类名），
   - 有特征 → `startFull()` 完整启动；
   - 无特征 → `startProbe()` 只挂一个轻量 MutationObserver，**不建面板、不扫描**；
   - 8 秒仍无特征 → `enterStandby()` 停掉全部定时器、看门狗、面板（待命观察器保留，
     页面之后真的出现播放内容——SPA 路由、延迟加载——自动唤醒）。
2. **待命守卫**：看门狗消息 / visibilitychange / window load / SPA 路由变化四个通道
   在待命期全部直接返回，杜绝"后台被唤醒后复活扫描"。
3. **权限收敛**：`host_permissions` 与 `web_accessible_resources` 从 `<all_urls>`
   收紧为与 `content_scripts` 相同的 27 域名白名单。

**三、其它**

- `escapeHtml()` 补全引号转义（授权原因等不可信文本插入 DOM 前转义）。
- 面板信息行追加授权状态（客户号/到期），激活与失效在调试日志可见。
- manifest 版本 2.1.0；`SETTINGS_VERSION` 保持 2.0.0（设置 schema 未变）。
- 网梯冻结区未动；`node tests/run-all.js` 全量 **137/137 通过**。

### v2.0.1（2026-10-13）平台名称更正

纯文案修正，无逻辑改动。

- **更正第二个平台的归属名称**：`jxnu.edu.cn` 是**江西师范大学**的 zjpt 学习平台，此前
  `content.js` 的 `PLATFORMS`、`popup.js` 平台清单、README / CHANGELOG 中误写为
  「江西专技学习网」，现统一更正为「江西师范大学」。
- 影响面：仅面板 / 弹窗上显示的平台名，以及 `platformInfo().name` 的诊断输出，
  不涉及任何平台判定逻辑（`detectPlatformByHost()` 按域名判定，不受影响）。
- 网梯冻结区未改动，`node tests/run-all.js` 全量自检仍为 89/89 通过。

### v2.0.0（2026-10-13）双平台策略隔离 + 平台前台开关

起因：每轮为 jxnu 修复问题时都要往通用路径里加特判（课时序号过滤、check-circle 判定、
空壳 video 过滤、自定义播放器接管），而这些都是**共享代码路径**——改新平台存在波及
原有网梯平台的风险。本版把两个平台的策略正式隔开。

**一、运行时 profile**

新增 `PLATFORMS` 定义（whaty / jxnu / generic）与 `detectPlatformByHost()`，按域名判定
`ACTIVE_PROFILE`。所有平台专属代码统一走 `profileAllows(id)` 准入：

| 代码块 | 归属 | 归入 profile 后的效果 |
|---|---|---|
| `.s_point[itemtype="video"]` 精准识别 | 网梯 | jxnu 域名上永不执行 |
| `completestate="1"` 完成判定 | 网梯 | jxnu 域名上永不采信 |
| `s_pointerct` 当前项判定 | 网梯 | jxnu 域名上永不采信 |
| `#learnMenu` 目录容器识别 | 网梯 | jxnu 域名上直接返回 null |
| 目录百分比 ≥99.5% 视为完成 | jxnu | 网梯域名上永不采信 |
| 课时序号过滤（剔除章节标题） | jxnu | 网梯/通用域名上不做剔除 |
| 百家云自定义播放器接管 | jxnu | `findCustomPlayerRoot()` 对网梯返回 null |

未识别到的站点归为 `generic`，此时两套专属逻辑**都放行**（向后兼容），
平台更换域名也不会导致功能整体失效——真正的隔离发生在两个已知平台之间。

**二、前台平台启停**

面板与 popup 均新增「平台启停」勾选列表（网梯标记「已冻结」）。关闭某个平台后：
- 该平台所属域名上 `shouldEarlyExit()` 直接返回 true，不建面板、不扫描；
- `ensurePlaying` / `customPlayerTick` / `catalogDrivenTick` 三个 tick 立即停手；
- 面板状态显示「本平台已停用」，并展示当前识别到的平台名。
可随时重新勾选开启（storage 实时同步，无需刷新页面重载策略）。

**三、网梯平台正式冻结**

- 网梯相关代码块标注 `【已冻结 v2.0.0】`，非必要不再改动；
- 新增 `tests/selftest_whaty_frozen.js` 作为**回归门禁**（20 项）：网梯黄金用例 +
  隔离门禁（jxnu profile 下不得采信网梯专属信号）+ 冻结标记完整性检查；
- 新增 `tests/run-all.js` 统一入口，合计 89 项自检。

```
node tests/run-all.js   # 改动合入前必须通过
```

### v1.9.3（2026-10-13）修复「刷新 / 进入视频页后必须人工点一次才会播」

现象：日志里 `自定义播放器: bplayer-wrap (25:01/40:05 未播)` 持续 60 多秒，扩展毫无动作，
用户每次都得自己点一下播放。

根因：自定义播放器的起播闸门是

```js
if (!settings.autoResume && !early && !justJumped) return;
```

- `autoResume`（暂停自动续播）出于规避平台检测的考虑**默认是关闭的**；
- `early` 的判据是 `cur <= 15`，而这次停在 **25:01（1501s）**，不满足；
- 也并非刚跳转过来的 `justJumped`。

三个条件同时落空 → 直接 return，永远不会出手。（这也解释了历史版本的矛盾表现：位置在 0 秒时
`early` 成立会去点，停在中途则完全不动。）

修复要点：

1. **把「首次起播」和「暂停续播」拆成两件事**
   新增设置 `autoStart`（进入页面自动起播，**默认开启**）。它只负责每一节的第一次播放：
   播放器一旦真的播起来（UI 转 playing 或播放位置推进）就立即收手，此后用户再暂停不会再插手。
   `autoResume` 维持原语义（默认关闭），不再承担"进入页面第一次起播"的职责。
2. **冷启动状态机**：接管播放器后先给 2.5 秒挂载时间，随后执行起播并按 3s/8s/16s 三次复查，
   没有真的播起来就升级到下一种方式（media.play → 自带按钮 → 画面 canvas → 画面容器 → 空格键）；
   窗口 8 分钟、最多 6 轮，避免无限骚扰。
3. **换课时的三个识别信号**（任一命中即重开冷启动窗口）：
   播放容器类名变化 / 本扩展刚发起跳转（解决"跳到下一集却不起播"）/ 播放位置大幅倒退。
   尤其第二条：SPA 平台切课时播放器 DOM 会被复用、类名完全一样，只靠类名会把新的一节课
   误认为同一个播放器，导致跳过去之后永远不起播。
4. **版本迁移不再偷偷抹掉用户选择**：旧逻辑每逢升级就强制把 `autoResume` 置回 false，
   会把用户手动勾选的结果悄悄还原。改为只在首次安装时写入默认值。
5. popup 与页面面板均新增「进入页面自动起播」开关。

自检 67/67 全通过（新增 `tests/selftest_autostart.js` 14 项行为级仿真，用虚拟时钟直接驱动
`customPlayerTick()`，覆盖刷新/跳集/换课/手动暂停/开关关闭/尝试上限/播完跳集七条时间线；
`selftest_customplayer.js` 增加 9 项源码级断言，防止 autoResume 闸门再次被误用）。

### v1.9.2（2026-10-13）热修：修复「一会播放、一会暂停」
现象：日志显示 `自定义播放器: bplayer-wrap (00:00/00:00 未播)`，但同一时刻控制条上其实已经是
`00:38 / 31:30`、`bplayer-playing` —— 播放器**明明在播**，扩展却把它读成"停在 0 秒"，于是每 8 秒
点一次播放按钮，而播放按钮/画面/空格键都是「播放↔暂停」开关，直接造成了反复切换。

读数失败的两处连带原因：
- **① 时长被外层容器吃掉**：百家云的时间容器本身也叫 `.duration`
  （`<span class="text duration">` 内部包着 `.played-time` 与 `.total-time`）。用 `[class*="duration"]`
  找总时长时 `querySelector` 先命中这个外层，`textContent` 变成 `"00:38/31:30"`，`parseClock` 必然失败。
  → 新增 `readPlayerClock()`：只用精确类名，并跳过内部仍嵌套时间元素的容器；仍取不到时按
  `"00:38 / 31:30"` 的成对格式在播放器文本里兜底扫描。
- **② 占位 `<audio>` 抢占了读数通道**：`<audio class="bplayer-audio">` 是百家云模板里的占位元素
  （无 src、readyState 0、currentTime 恒 0），只要它存在，代码就走 media 分支、完全不读 DOM 文本。
  → 增加"media 是否真的可用"判定（有 src/currentSrc/srcObject 或 readyState>0 或 currentTime>0），
  不可用就改用控制条文本，并记录 `trackable` 标记当前能否追踪播放位置。

三重防误暂停保护（针对"用点击去救一个其实没坏的视频"）：
1. UI 明确显示"播放中"时，判定卡住的等待从 8 秒放宽到 **90 秒**；
2. 读不到播放位置且 UI 说在播，一律**不出手**；
3. 点击后的复查（5s/8s/16s）一旦发现 UI 变为"播放中"就**立刻收手**。
另有：**目录进度驱动不再负责起播** —— 自定义播放器可追踪时，改由秒级的 `customPlayerTick` 接管，
避免长视频几十秒才涨 0.1% 被误判成"卡住"再去点画面/空格。

自检增至 44 项（新增 readings 陷阱用例，直接用日志里的 `00:38 / 31:30` 结构与 `2.01%` 进度条做校验），全部通过。

### v1.9.1（2026-10-13）
依据发来的播放器区域 DOM 定位到两个致命问题，jxnu zjpt 连播失效的根因终于水落石出：

- **① 目录驱动的 tick 一直在崩（静默）**：`catalogDrivenTick()` 里用了两个从未声明/从未实现的标识符 —— 变量 `catalogDriveAnnounced` 与函数 `currentItemPausedByIcon(cur)`。文件顶部有 `'use strict'`，读取未声明变量直接抛 ReferenceError，而该 tick 挂在 3 秒轮询里且没有 try 包裹：**每 3 秒崩一次，起播级联（含 v1.9.0 新增的四级兜底）一行都没执行到**。现已补齐声明与实现，并给轮询加 try 兜底，单个环节出错不再拖垮整条链路。
- **② 播放器根本没有 `<video>` 元素**：jxnu zjpt 用的是百家云 bplayer —— 画面渲染在 `<canvas id="bplayer-ffplayer">`，声音走 `<audio class="bplayer-audio">`，页面里一个 `<video>` 都没有。此前所有"存在真实 video 才起播/才驱动"的分支全部落空：面板读不到进度、收不到 ended 事件、也不自动播放。
  - 新增**自定义播放器接管模块**：直接从播放器 DOM 读状态（`.played-time`/`.total-time` 时间文本、`audio` 元素、进度条宽度、容器 `bplayer-playing` 类、播放按钮渲染的是暂停图标还是播放图标），并把它伪装成一条标准 `from:'custom'` 视频状态注入既有流水线 —— 面板进度、卡结尾检测、"播完自动下一集"等全部照常生效。
  - 新增**起播级联 + 事后校验**：① 调 `media.play()`（幂等）→ ② 点播放器自带播放按钮 → ③ 点画面 canvas → ④ 点画面容器 → ⑤ 派发空格键；点击后 3s/8s/16s 复查播放位置有没有真的往前走，没走动就升级到下一种方式。
  - 判定基准是**"播放位置 8 秒没推进"**，而不是"看起来暂停了"，因此不会把一个正在正常播放的视频误点成暂停。
- **修复摄像头空壳冒充"正在播放"**：`ensurePlaying()` 的 `playing` 判定原先包含所有 video，页面常驻的摄像头/人脸检测 `<video>` 一直处于 playing，把"点页面播放按钮"这条唯一兜底也给堵死了；现改为只统计真实可播 video。
- 目录驱动不再被 `from:'custom'` 的伪装条目挡回；诊断行新增自定义播放器实时状态；「复制目录HTML」额外附上本课件的自定义播放器 DOM（`<!-- CUSTOM-PLAYER -->`）。
- 防连跳：跳转后 20 秒内不做"播完"判定（SPA 切课时播放器会先复用再重建，否则会连跳跳过一节课）。
- 新增自检 `tests/selftest_customplayer.js`（24 项），累计 41 项断言全部通过。

### v1.9.0（2026-10-13）
- 实机日志确认桥已安装但"关闭 Shadow 容器 0 个"——播放器不在 closed Shadow DOM。起播改为四级级联：控制条播放按钮 → **点击播放器画面区域**（自定义播放器通用交互，仅在有进度反馈保护时触发）→ **向播放器容器派发空格键** → 课时行播放图标。
- 扫描范围新增 `<object>/<embed>` 嵌套文档（播放器可能藏身之处），桥同步覆盖。
- 桥上报注入时机（ms），用于判断"容器 0"是否因注入偏晚而失真。
- 「复制目录HTML」现在会附带播放器区域候选 DOM（最大 3 块），便于精准适配。
- 0% 起播介入阈值 20s→35s（平台约每 30 秒才刷新一次百分比，避免误判）。

### v1.8.9（2026-10-13）
- **Shadow 桥注入消灭竞态**：改用 `chrome.scripting.registerContentScripts(world:'MAIN', runAt:'document_start')` 原生注册，由浏览器在每帧文档创建时抢先注入，保证 attachShadow 钩子先于播放器库安装；内容脚本侧另增「同步 XHR 取源码 + 内联执行」通道兜底。
- 桥脚本增强：上报已截获的关闭 Shadow 容器数量；`play()` 被自动播放策略拒绝时，自动改点容器内的播放按钮。
- 目录进度驱动的起播路径优先向 Shadow 播放器下发播放命令。
- 诊断行新增 Shadow 桥状态（已安装/未安装、容器数、video 数），便于定位；重复起播日志节流至 15 秒。

### v1.8.8
- 依据截图（页面底部有真实播放器控制条 18:29/33:46，但可播 video 为 0、iframe 为 0）定位：**课程播放器藏在「关闭的 Shadow DOM」里**，querySelectorAll 永远查不到。
  - 新增 `shadow_bridge.js`：注入页面主世界，包装 `Element.prototype.attachShadow` 截获 closed shadowRoot 引用，把其中 video 的状态（时间/时长/暂停/结束/倍率）经 `data-ap-shadow-videos` 属性回传，并经 `data-ap-cmd` 接收 play/rate 命令。双通道注入（`<script src>` 直连 + `chrome.scripting` 主世界注入兜底，不受页面 CSP 限制）；content script 提前到 `document_start` 以抢在播放器库之前装钩子。
  - Shadow 播放器接入主流程：状态并入全局聚合 → 支持自动起播、播完自动下一集、倍速；页面早退判断延迟到 init（document_start 下 DOM 未解析，避免误判普通网页无视频）。
  - **修复 v1.8.7 引入的图标误判**：`pause-circle` 实为"已开始未完成"而非"正在播放"，此前会导致进度卡住也不起播。现在只把 `check-circle` 当"已完成"，且当前课时图标变 check 时立即跳下一集（不等百分比刷满）。
  - 页面播放按钮兜底扩展：排除课程目录区（防止点到目录里的播放图标乱跳），新增宽泛 `[class*="play"]` 兜底选择器。
  - manifest 新增 `scripting` 权限与 `web_accessible_resources`。

### v1.8.7
- 依据 jxnu zjpt 实机日志修复「不自动播放 / 播完不跳下一集」，根因是**空壳 video 被当成了可控播放器**：
  - **核心根因**：日志里 3 个 video 全部 `无src / readyState 0 / duration NaN`（父级 `show-face`、`show_camera`、`my-video`，实为摄像头与人脸检测元素）。它们在 `getAggregatedVideos()` 里非空，导致 `目录进度兜底` 的第一行 `if (getAggregatedVideos().length > 0) return;` 直接返回 —— 按进度驱动的自动连播**从未生效过**。新增 `isRealVideo()/isRealVideoObj()` 剔除空壳，兜底恢复工作。
  - **播完自动跳下一集**：目录进度 ≥99.5% 即跳转；停在 95% 以上 4 分钟 / 90% 以上 8 分钟无变化也判定播完，避免平台不刷满 100% 时卡死。
  - **自动起播**：进度卡住不动时（0% 卡 20 秒、中途停 45 秒）尝试恢复 —— 先找页面播放按钮，找不到再点当前课时的播放图标；平台图标显示"正在播放"时不干预，绝不把在播的视频点暂停。
  - **完整鼠标事件序列**：新增 `fireFullClick()`（pointerdown→mousedown→pointerup→mouseup→click），Vue / Ant Design 平台只认真实事件序列，此前 `el.click()` 无效。
  - 面板与日志改进：区分「可播视频 / 空壳 video」计数；新增诊断行 `video 元素 N 个（可播 X，空壳 Y）`；进入目录进度驱动模式时明确提示。
  - 新增 `tests/selftest_videostate.js`（12 项断言）验证空壳过滤与百分比解析，网梯不受影响。

### v1.8.6
- 依据 jxnu zjpt 实机日志 + 目录 HTML 修复「点击下一集没反应 / 不自动播放 / 已播统计为 0」：
  - **「立即播放下一集」点了没反应（核心根因）**：扩展在页面里按文本找"下一集"按钮时，命中的是**自己面板上的那个按钮**（日志 `按文本命中下一集按钮： ▶ 立即播放下一集`），点了等于没点。现在悬浮面板带 `data-ap-own` 标记，`isOwnEl()` 会在查找下一集按钮、播放按钮、目录容器时一律排除自身元素。
  - **跳转改为目录优先**：原先先找平台"下一集"按钮、找不到才用目录。现改为目录优先（能精确定位下一个课时、顺序可控），平台按钮仅作兜底 —— 避免历史出现过的乱跳。
  - **目录项点击改为点内层元素**：Vue 平台（jxnu）把点击事件绑在 `li > div.course-detail` 上，点外层 `li` 不会触发。现在优先点内层容器（事件向上冒泡，两种绑定方式都能命中）。
  - **已完成识别补全**：该平台用 Ant Design 图标 `anticon-check-circle` 标记已完成（之前规则不认，导致"已播 0"）；另新增"课时进度条内联宽度达 100%"判定。
  - **自动起播增强**：新增 `hasMediaSource()`，跳过没有媒体源的空壳 video（此前对 3 个占位 video 反复尝试起播无效）；`play()` 失败时输出失败原因，并退回 `clickPagePlayButton()` 点击页面播放按钮（仅在刚跳转后或已开启自动续播时，30 秒节流，不会打扰用户手动暂停）。
  - **诊断增强**：绑定视频时输出 有源/readyState/duration/paused/class/父级；跳转后 2 秒复查当前项是否切换，输出「已切换 / ⚠️ 当前项未变化」。

### v1.8.5
- **回归防护：确保新增的 jxnu 平台适配不影响网梯（webtrn.cn / whaty-learnspace）原有识别与连播**。逐项审查 v1.8.3 / v1.8.4 的通用化改动后，对 3 处存在回归风险的逻辑加了保护：
  - **课时序号过滤加双重保护**（`filterLessonLeaves`）：网梯若被误过滤会直接导致目录识别失效。新增 ①候选含 `.s_point[itemtype="video"]` 时直接跳过过滤；②被剔除的候选中若存在"明确课时特征"（`onclick` 含 `openLearnResItem` / `itemtype=video` / `completestate` / `s_point` 等课时类名）则放弃过滤。网梯平台永远走原有精准路径。
  - **本地完成记账改为带 10 分钟有效期**（`localDoneMap`）：原先是永久记账，万一当前项识别偶发错误会把未播课时永久标为已完成，破坏 v1.7.7 的"播完自动补齐漏看课时"。现在过期自动失效，恢复为未完成。
  - **用户主动暂停的判定收紧**：只有视频已播放超过 15 秒后的前台暂停才认定为用户主动暂停。网梯切课时视频常在开头（0 秒）暂停，此前会被误判成"用户暂停"而不再自动起播。
- 新增 `tests/selftest_lessonfilter.js` 静态自检脚本：直接从 `content.js` 提取真实函数源码运行，覆盖 jxnu（13 课时 / 剔除 4 章节标题）与网梯 3 种场景 + 通用平台场景，共 5 项断言全部通过，后续改动可复跑验证（`node tests/selftest_lessonfilter.js`）。

### v1.8.4
- 依据 jxnu zjpt 实机日志修复目录识别与无视频场景，并修复「复制目录HTML」失效：
  - **「复制目录HTML」点了没反应（已修）**：顶层只向子帧广播收集请求，没把自己（顶层）的目录 HTML 写进缓冲区，目录在顶层时缓冲区始终为空，提示"未收到目录HTML"。现在顶层目录 + 全部 iframe 地址一并入缓冲，无论复制成功失败都有明确日志反馈。
  - **章节标题被当成课时（数量不准的根因）**：日志显示 17 项里混入了 4 个 `SPAN.nav-title` 章节标题（真实课时只有 13 个）。新增 `filterLessonLeaves()`：课时文本带序号（"1-1"/"2.3"）、章节标题不带，据此剔除；仅在"带序号的占多数"时生效，不影响不带序号的平台。
  - **进度百分比可利用**：新增 `parseItemPercent()` 解析目录项上的进度（80.4%/100%），日志「目录分析」行会输出当前课时进度。
  - **无视频状态也能连播**：播放器位于跨域 iframe 时监听不到 ended 事件。新增 `progressDrivenFallback()`——监听不到 video 时改由目录进度驱动，课时进度到 100% 即自动跳下一集；若平台停在 99% 不再增长，连续 4 分钟无变化也判定播完（防卡死）。
  - **面板进度不再空白**：无视频状态时用平台目录的课时进度百分比填充进度条，并注明"播放器跨域"。
  - **日志降噪 + 诊断增强**：目录状态无变化时不再每 3 秒刷一大段（此前会冲掉前面的日志）；目录分析后输出「本页 video 元素 N 个 | iframe M 个 → 地址清单」，便于判断播放器位置。

### v1.8.3
- 修复 **jxnu zjpt（zjpt-web.jxnu.edu.cn/learning）平台检测数量不对、已播/待播不准、跳转后不自动播放** 的问题：
  - **跳转后不自动起播（核心）**：起播检查 `ensurePlaying()` 此前只在后台看门狗（每分钟一次）里执行，前台循环未调用 —— 自动跳到下一集后新视频停在暂停态，最多要等一分钟才被拉起。现在前台 3 秒循环、子帧 1.5 秒循环、`ping` 应答均执行起播检查，跳转后几秒内即自动开播。
  - **时长未知的视频也能起播/显示进度**：该平台自定义播放器的 `duration` 可能为 0/未知，旧逻辑直接跳过这类视频（表现为「视频在播但进度 0%」）。现在 `duration` 未知时按 `currentTime < 2` 判定"未起播"照样拉起；面板进度在时长未知时显示「当前 xx:xx / 未知时长」。
  - **已播/待播按百分比判定**：该平台不用 class 标记完成，而是在课时上显示学习进度百分比（0.0% / 78.9% / 100%）。新增规则：目录项文本中百分比 ≥ 99.5% 判定为已完成。
  - **本地完成记账**：SPA 跳转后 URL 与目录高亮可能不变、平台完成状态延迟更新，存在反复跳回同一集的风险。视频播完或自动跳转时在本地把当前课时记为已完成（仅运行时，刷新即重置），保证按目录顺序持续推进。
  - **视频计数去重**：部分页面存在多个相同 `src` 的重复 video 元素（清晰度切换预置等），面板视频数按 `src` 去重，更接近真实数量。
  - **用户主动暂停保护**：前台手动暂停（未开自动续播时）会被记录，起播逻辑不会抢启；后台被动暂停不受影响。
  - **覆盖跨域播放器 iframe**：`manifest.json` 与内容脚本新增常见第三方视频云域名（CC视频 bokecc.com、保利威 polyv.net、阿里云 aliyuncs.com、七牛 qiniudns.com、华为云 cdnhwc1/cdnhwc2.com）—— 若播放器嵌在这些跨域 iframe 里，此前完全监听不到播放结束事件。页面加载后会输出全部 iframe 地址到日志，便于后续精准适配。

### v1.8.2
- **添加原创性 / 著作权声明，防止他人删除署名后冒称原创**（署名统一为「胡昱晨 (hu_yu_chen)」）：
  - 所有源文件顶部统一加入标准版权头：`content.js`、`background.js`、`popup.js`、`content.css`（`/*! */` 块注释）、`popup.html`（HTML 注释）。内容涵盖著作权归属、MIT 授权说明、署名不可移除、禁止冒名、修改须标注、免责声明，中英文对照。
  - `manifest.json` 内嵌版权信息：新增 `author` 字段，`description` 与 `default_title`（扩展图标悬停提示）均带 © 署名，安装界面与工具栏即可见。
  - 界面可见署名：悬浮面板底部新增常驻版权行；扩展弹窗底部新增署名区块。他人改包发布时会保留作者印记。
  - `README.md` 顶部新增醒目著作权声明，并补充「版权与二次分发」章节。
  - 功能逻辑无任何改动。

### v1.8.1
- 修复「浏览器最小化 / 切到后台后不再自动播放、也不自动跳转下一集」：
  - **根因**：Chrome 对后台标签页实施定时器节流（隐藏一段时间后 `setInterval` 被压缩到每分钟一次）。而 `pickBestFrameForNext` / `pickBestList` 以 12 秒有效期过滤 `frameStates`，另有 15 秒清理定时器直接 `delete frameStates[k]`；后台时帧状态被判定过期或删除，`pickBestFrameForNext()` 返回 `null`，日志打出「未找到有效目录帧」于是不跳转。回到前台后定时器恢复，积压任务一起执行，表现为「打开浏览器才继续」。
  - **按可见性放宽时效**：新增 `frameStateMaxAge()`，页面不可见时有效期 15 秒 → 5 分钟（目录结构不因后台而改变），前台保持严格；`frameStates` 清理定时器同步放宽。
  - **调度改为消息驱动**：`ended` 到达时先 `analyzeAndReport()` + `broadcastDown({type:'ping'})` 实时拉起子帧上报（`postMessage` 投递不受定时器节流影响）；抽出统一入口 `dispatchNext(reason, allowRetry)`，选不到目录帧时安排一次重试。
  - **新增后台看门狗**：新增 `background.js`（MV3 Service Worker）配合 `chrome.alarms`，每分钟唤醒一次，向已注册标签页发消息执行「扫描视频 → 刷新目录 → 保播 → 必要时补跳下一集」。消息投递会立即执行页面脚本，不受节流限制。仅需 `storage`（已有）+ `alarms`，无需 `tabs` 权限。
  - **被动暂停自动恢复**：区分用户主动暂停与后台被动暂停。页面不可见时发生的暂停（浏览器节流或平台防挂机检测）自动恢复播放，前台主动暂停不受影响。
  - **保证下一集真的起播**：新增 `ensurePlaying()`，视频 `currentTime < 15` 却处于暂停时自动尝试启动（优先模拟点击播放按钮，`play()` 兜底）。
  - **恢复可见即时补齐**：`visibilitychange` 回到前台时立即刷新并检查是否有遗漏跳转。

### v1.8.0
- 新增支持 **江西师范大学（zjpt 学习平台）** `zjpt-web.jxnu.edu.cn`。
- **修复通用平台无法连播的根本问题**：`hasRealCatalogInList` / `clickNext` 原先写死只认网梯平台 `.s_point[itemtype="video"]`，任何新平台都会被判为「无目录」而拒绝跳转。

### v1.7.9
- 新增**倍速播放**功能：
  - 默认 1 倍速，最高 5 倍速，档位：1.0x / 1.25x / 1.5x / 2.0x / 2.5x / 3.0x / 4.0x / 5.0x。
  - 悬浮面板新增「倍速播放」开关 + 「播放速度」下拉选择；扩展图标弹窗同样支持设置。
  - 默认**关闭**（`speedEnabled: false`），避免与平台自带倍速冲突或触发违规检测；开启后所有帧的视频统一应用倍速。
  - 视频切换（重新播放）时自动重新应用倍速，防止播放器重置；设置实时同步到所有已打开页面，关闭开关即恢复 1 倍速。

### v1.7.8
- 两层保护，扩展只在有视频的网页生效：
  - `manifest.json` 的 `matches` 收紧到常见视频/网课平台（25+ 域名）：网梯 `webtrn.cn`、B站、优酷、爱奇艺、腾讯视频、网易云课堂、中国大学MOOC、学堂在线、智慧树、慕课网、超星、网易公开课、腾讯课堂、高顿、抖音、快手、虎牙、斗鱼、YouTube 等；不在列表里的网站扩展完全不会注入，从根源上不触发。
  - `content.js` 顶层 frame 启动 `earlyExit`：启动时检测「不在已知平台域名 且 没有 `<video>` 元素」→ 整个 IIFE 立即 return；不绑定任何事件监听器、不创建悬浮面板、不扫描 DOM。子 frame 保持原状（依赖父 frame 唤醒），但子 frame 只会在匹配的网课子页面里注入。
  - 兜底逻辑：任意网站只要存在 `<video>` 元素仍正常工作，防止漏掉新平台。


### v1.7.7
- 修复「仍未按顺序播放，且播完最后一个视频后不会回头补齐漏看课时」：
  - `findNextItem` 改为**自动补齐模式**：自动连播时按目录顺序取**第一个未完成课时**，不再局限于「当前项之后」。这样即使前面有漏掉的视频，播完后也会回头继续播放，直到课程全部完成。
  - 手动点击「立即播放下一集」仍优先取当前项之后的下一个未完成课时，保持操作预期；当前项之后没有待播项时，再兜底取全局第一个未完成项。
  - `clickNext` 增加 `autoEnded` 参数，自动结束事件与手动按钮使用不同策略，并在跨帧广播中传递 `manual` 标志。
  - 全部课时完成后日志输出「全部课时已完成」，避免无意义重复跳转。

### v1.7.6
- 修复「v1.7.5 仍未拦住播放器帧乱点 / 当前项识别错位」：
  - `clickNext` 目录有效性判断由「leafCount ≥ 3」改为「本帧必须含 `.s_point[itemtype="video"]`」。网梯内容帧（播放器控件）即便识别出 3 项也不算目录，必须让顶层调度到真正拥有 `.s_learnlist` 的目录帧。
  - `pickBestFrameForNext` 同样过滤掉不含 `.s_point` 的无效帧，委派的目标帧一定是真实目录帧。
  - `analyzeList` 当前项识别顺序改为 **URL 匹配优先**，再退回到 `s_pointerct` 类标记。原因：平台可能在目录上保留对某一项的 `s_pointerct` 高亮，但用户实际播放的是另一项（URL 不同），此时按 `s_pointerct` 找当前项会指错，导致下一集跳过多个真实未看项。
  - 行为：用户从 leaf[N]（未标 `s_pointerct`）播放结束 → 用 URL 识别为 leaf[N] → 下一集严格取 leaf[N+1] 之后的第一个非已完成项。

### v1.7.5
- 修复「播完下一集仍不按顺序乱跳」：
  - 顶层统一调度：视频结束后由顶层挑选「目录项最多」的帧执行下一集，避免多个 iframe 同时点击导致乱跳；
  - 子帧目录项不足 3 个时不再处理下一集，防止播放器画质选择（全高清等）被误当目录点击；
  - 网梯平台直接调用 `openLearnResItem(itemId, 'video', null, title)`，比点击元素更稳定；
  - 新增全局 8 秒跳转锁，防止重复触发下一集。

### v1.7.4
- 修复「播完跳转下集不按顺序、中间跳过的视频被误认为已看完」：
  - 目录状态判定只信任平台真实标记（`completestate="1"`、`s_pointerct` 等），不再把当前项之前的所有课时默认标为已播；
  - 修复后：跳过未看的视频仍保持「待播」，课程总进度与待播数量与平台实际状态一致；
  - `findNextItem` 严格按 DOM 顺序取当前项的下一个非已完成课时，避免跳集。

### v1.7.3
- 修复「点击播放下一集仍跳回当前正在播放的视频」：
  - `findWangtiCatalog` 移除 `.learn-menu`（左侧导航）误命中，只认 `#learnMenu` / `.s_learnlist` 等真正的课程目录；
  - 目录容器搜索改为跨所有同域 iframe 取评分最高者，`.s_point[itemtype="video"]` 目录永远优先，左侧导航强烈减分；
  - 移除「兜底点击随机元素」逻辑（此前顶层帧找不到下一节时会乱点顶层元素，导致跳到当前视频）；
  - 「下一集」支持跨帧委托：没有目录的帧返回失败后，由顶层广播给拥有目录的子帧执行精准跳转，子帧成功即停止向下广播。
- 日志新增帧标识（`TOP` / `IFRAME|页面名`），便于定位问题帧。

### v1.7.2
- 修复 `collectItems` 中 `const candidates` 被重新赋值导致的 `Assignment to constant variable` 错误（该错误使目录分析中断）。
- 目录识别优先使用网梯平台专用 `findWangtiCatalog`，避免把左侧「课件/课程简介/学习进度」导航菜单当成课程目录。
- 在启发式评分里：包含 `.s_point[itemtype="video"]` 大幅加分，包含 `.learn-menu-cell` 大幅减分。
- `collectItems` 增加过滤，排除左侧导航、播放器控件（高清/标清等）等非课时项。

### v1.7.1
- 加入设置版本迁移：升级后强制把「暂停自动续播」重置为关闭，避免旧设置残留导致继续触发平台警告。
- 进一步增强网梯平台目录识别：新增 `findWangtiCatalog`，直接命中 `#learnMenu` / `.s_learnlist` / `[class*="learnlist"]`，并以包含最多 `.s_point[itemtype="video"]` 的 `div` 作为兜底。

### v1.7
- **风险规避**：默认关闭「暂停自动续播」，移除直接调用 `video.play()` 的逻辑，改为仅在开启开关时模拟点击播放按钮。
- 降低视频进度上报频率（500ms → 2000ms）和子帧 ping 频率（1s → 3s），减少被平台检测为异常播放的可能性。
- 面板与弹窗对「暂停自动续播」增加 ⚠️ 风险提示。
- 修复目录识别为 0 项：增加对网梯平台 `#learnMenu` / `.s_learnlist` 的直接命中与兜底选择。

### v1.6
- 针对网梯 / whaty-learnspace 课程平台做精准适配：
  - 目录叶子项直接识别 `.s_point[itemtype="video"]`，避免取到内部 `.wrap` 导致 class/状态丢失；
  - 已完成状态读取 `completestate="1"` 属性；
  - 当前播放中状态识别 `s_pointerct` 类；
  - 当前课时通过 `onclick` 中的 `itemId` 与 URL 中的 `params.itemId` 前 8 位匹配，解决无 `<a href>` 时无法定位当前项的问题。
- 课程总进度计算更准确：1 个已完成 + 1 个播放中 + 11 个待播 = 13 项。

### v1.5
- 目录识别只保留“带播放时长的视频课时”，剔除「第X讲」「章节」等非视频项，避免把 15 项误算成视频数。
- 当前课时定位增强：支持从目录项的 `onclick` / `data-*` 属性中提取真实跳转链接，再与当前 iframe URL 匹配。
- 面板新增「复制日志」「复制目录HTML」按钮，可一键复制识别结果与目录 HTML，方便针对性适配。
- 调试日志改为输出全部课时的文本、类名、完成标记、跳转链接。

### v1.4
- 修复“所有课时都识别为已播、课程总进度 100%”的误报：
  - 已完成检测更严格，避免 `checkbox` / `checked` 等子元素误匹配；
  - 新增“URL 匹配”定位当前课时，适配 whaty / webtrn 类课程平台；
  - 新增页面标题、章节标题匹配当前课时；
  - 当全部课时都被标记为已完成、但当前视频尚未结束时，自动判定为误报并清空已完成标记。
- 调试日志默认输出目录分析详情，方便定位识别问题。
